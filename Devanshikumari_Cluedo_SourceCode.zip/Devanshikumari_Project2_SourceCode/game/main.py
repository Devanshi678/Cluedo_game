from board import rooms, room_connections
from characters import characters
from weapons import weapons
from mystery import generate_solution
from player import Player
from suggestion import make_suggestion, check_suggestion, refute_suggestion
import random

def main():
    print("🎩 Welcome to Cluedo!")
    num_players = int(input("\nEnter number of players (2-6): "))
    available_characters = list(characters.keys())
    players = []

    for i in range(num_players):
        print("\nCharacters Available:")
        for ch in available_characters:
            print(f" - {ch} (Starts in {characters[ch]})")

        while True:
            selected = input(f"Player {i+1}, choose your character: ").strip()
            if selected in available_characters:
                starting_room = characters[selected]
                player = Player(name=f"Player {i+1}", character_name=selected, starting_room=starting_room)
                players.append(player)
                available_characters.remove(selected)
                break
            else:
                print("❌ Invalid character or already taken. Try again.")


    print(f"\n🕵️ You are {player.name}, starting in the {player.current_room}.")

    # Generate the murder mystery
    solution = generate_solution()
    # Remove the solution cards from the deck
    deck = [w for w in weapons if w != solution['weapon']] + \
            [c for c in characters if c != solution['suspect']] + \
            [r for r in rooms if r != solution['room']]

    random.shuffle(deck)

    # Deal cards to players
    while deck:
        for player in players:
            if deck:
                player.hand.append(deck.pop())


    # Game loop
    while True:
        for player in players[:]:
            print(f"\n🎮 {player.name}'s turn ({player.character})")
            accuse = input("Would you like to make an accusation? (yes/no): ").lower()
            if accuse == "yes":
                acc_suspect = input("Enter the suspect you want to accuse: ")
                acc_weapon = input("Enter the weapon: ")
                acc_room = input("Enter the room: ")
    
                accusation = {
                    "suspect": acc_suspect,
                    "weapon": acc_weapon,
                    "room": acc_room
                }

                if check_suggestion(accusation, solution):
                    print(f"🎯 {player.name} has made a correct accusation and wins the game! 🏆")
                    return
                else:
                    print(f"❌ {player.name}'s accusation was wrong. They're out of the game!")
                    players.remove(player)
                    print("Remaining players:", ", ".join([p.name for p in players]))
                    if len(players) == 0:
                        print("All players are out. No one solved the mystery.")
                        return
                    continue  # Skip rest of this player's turn

            print(f"🏠 You are currently in the {player.get_location()}")
            print("Connected rooms:", room_connections[player.get_location()])

            # Move to another room
            move = input("Enter a room to move to (or type 'stay' to stay here): ")
            if move.lower() != 'stay':
                player.move_to(move, room_connections)

            # Make a suggestion
            current_room = player.get_location()
            print(f"\n🔍 You're now in the {current_room}. Time to make a suggestion.")
            suspect = input("Enter the suspect's name: ")
            print("Available weapons:", weapons)
            weapon = input("Enter the weapon: ")

            suggestion = make_suggestion(current_room, suspect, weapon)
            print(f"\n{player.name} suggested it was {suggestion['suspect']} in the {suggestion['room']} with the {suggestion['weapon']}.")

            refuted = refute_suggestion(player, players, suggestion)
            if not refuted:
                if check_suggestion(suggestion, solution):
                    print(f"🎉 {player.name} solved the murder mystery! They win! 🏆")
                    return
                else:
                    print("❌ That's not the correct solution.")
            else:
                print("🔄 Turn passes to the next player.")


if __name__ == "__main__":
    main()