class Player:
    def __init__(self, name, character_name, starting_room):
        self.name = name
        self.character = character_name
        self.current_room = starting_room
        self.hand = []

    def move_to(self, new_room, connections):
        if new_room in connections.get(self.current_room, []):
            self.current_room = new_room
            print(f"{self.name} moved to {new_room}")
        else:
            print(f"Can't move to {new_room} from {self.current_room}")

    def get_location(self):
        return self.current_room