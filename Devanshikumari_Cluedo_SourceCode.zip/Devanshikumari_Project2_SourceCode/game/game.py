# game/game.py
import random
from .characters import CHARACTERS
from .weapons import WEAPONS
from .board import Board
from .mystery import generate_mystery
from .player import Player
from .suggestion import make_suggestion

class Game:
    def __init__(self, player_names):
        self.board = Board()
        self.players = []
        self.current_turn = 0
        self.solution = generate_mystery()
        self.weapons = WEAPONS.copy()

        available_characters = list(CHARACTERS.keys())
        random.shuffle(available_characters)

        # Assign players characters and hands
        for name in player_names:
            char = available_characters.pop()
            player = Player(name, char)
            self.board.place_player(player)
            self.players.append(player)

        self.deal_cards()

    def deal_cards(self):
        all_cards = list(CHARACTERS.keys()) + WEAPONS + list(self.board.rooms.keys())
        # Remove the solution from the deck
        for s in self.solution:
            all_cards.remove(s)
        random.shuffle(all_cards)

        # Deal remaining cards
        i = 0
        while all_cards:
            card = all_cards.pop()
            self.players[i % len(self.players)].hand.append(card)
            i += 1

    def next_turn(self):
        self.current_turn = (self.current_turn + 1) % len(self.players)
        return self.players[self.current_turn]

    def get_other_players(self, current_player):
        return [p for p in self.players if p != current_player]
