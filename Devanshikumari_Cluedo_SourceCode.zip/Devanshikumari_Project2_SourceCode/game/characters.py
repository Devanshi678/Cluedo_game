characters = {
    "Miss Scarlett": "Lounge",
    "Colonel Mustard": "Dining Room",
    "Mrs. White": "Kitchen",
    "Mr. Green": "Conservatory",
    "Mrs. Peacock": "Library",
    "Professor Plum": "Study"
}
