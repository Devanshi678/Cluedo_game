def make_suggestion(current_room, suspect, weapon):
    return {
        "room": current_room,
        "suspect": suspect,
        "weapon": weapon
    }

def check_suggestion(suggestion, solution):
    return suggestion == solution

def refute_suggestion(suggesting_player, players, suggestion):
    print("\n🔎 Checking if anyone can refute the suggestion...")

    for player in players:
        if player == suggesting_player:
            continue  # Skip the player who made the suggestion

        # Find matching cards
        matches = []
        if suggestion['suspect'] in player.hand:
            matches.append(suggestion['suspect'])
        if suggestion['weapon'] in player.hand:
            matches.append(suggestion['weapon'])
        if suggestion['room'] in player.hand:
            matches.append(suggestion['room'])

        if matches:
            print(f"{player.name} can refute the suggestion.")
            # Let player choose which card to show if multiple
            if len(matches) > 1:
                print(f"Matching cards: {matches}")
                card_to_show = input(f"{player.name}, choose a card to show {suggesting_player.name}: ")
                while card_to_show not in matches:
                    card_to_show = input("Invalid choice. Pick from the matching cards: ")
            else:
                card_to_show = matches[0]
            
            print(f"{player.name} shows a card to {suggesting_player.name}: {card_to_show} 🔐")
            return True  # Refutation happened

    print("🚫 No one could refute the suggestion.")
    return False