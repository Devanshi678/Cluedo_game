import random
from characters import characters
from weapons import weapons
from board import rooms

def generate_solution():
    return {
        "suspect": random.choice(list(characters.keys())),
        "weapon": random.choice(weapons),
        "room": random.choice(rooms)
    }