rooms = [
    "Kitchen", "Ballroom", "Conservatory", "Dining Room", 
    "Lounge", "Hall", "Study", "Library", "Billiard Room"
]

# Simple adjacency map: room connections
room_connections = {
    "Kitchen": ["Ballroom", "Dining Room"],
    "Ballroom": ["Kitchen", "Conservatory", "Billiard Room"],
    "Conservatory": ["Ballroom", "Library"],
    "Dining Room": ["Kitchen", "Lounge"],
    "Lounge": ["Dining Room", "Hall"],
    "Hall": ["Lounge", "Study"],
    "Study": ["Hall", "Library"],
    "Library": ["Conservatory", "Study", "Billiard Room"],
    "Billiard Room": ["Ballroom", "Library"]
}